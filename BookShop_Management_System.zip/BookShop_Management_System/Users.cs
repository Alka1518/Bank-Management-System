﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BookShop_Management_System
{
    public partial class Users : Form
    {
        public Users()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Users\alkas\source\repos\BookShop_Management_System\Database1.mdf;Integrated Security=True"))
            {
                con.Open();
                using (SqlCommand cnn = new SqlCommand("insert into UserTable (user_name, user_phone, user_address, user_password) values(@user_name,@user_phone,@user_address,@user_password)", con))
                {
                    cnn.Parameters.AddWithValue("@user_name", textBox1.Text);
                    cnn.Parameters.AddWithValue("@user_phone", textBox2.Text);
                    cnn.Parameters.AddWithValue("@user_address", textBox3.Text);
                    cnn.Parameters.AddWithValue("@user_password", textBox4.Text);

                    cnn.ExecuteNonQuery();
                }
                MessageBox.Show("Record Saved Successfully!");
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Users\alkas\source\repos\BookShop_Management_System\Database1.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("delete UserTable where User_Id=@User_Id", con);
            cnn.Parameters.AddWithValue("@User_Id", int.Parse(textBox1.Text));
            cnn.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Record Deleted Successfully!");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            dataGridView1.ClearSelection();
        }

        private void Users_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Users\alkas\source\repos\BookShop_Management_System\Database1.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("Select * from UserTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Users\alkas\source\repos\BookShop_Management_System\Database1.mdf;Integrated Security=True"))
            {
                con.Open();
                string query = "INSERT INTO UserTable (user_name, user_phone, user_address, user_password) VALUES (@user_name, @user_phone, @user_address, @user_password)";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@user_name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@user_phone", textBox2.Text);
                    cmd.Parameters.AddWithValue("@user_address", textBox3.Text);
                    cmd.Parameters.AddWithValue("@user_password", textBox4.Text);

                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("Record Updated Successfully!");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Users\alkas\source\repos\BookShop_Management_System\Database1.mdf;Integrated Security=True");
            con.Open();
            SqlCommand cnn = new SqlCommand("Select * from UserTable", con);
            SqlDataAdapter da = new SqlDataAdapter(cnn);
            DataTable table = new DataTable();
            da.Fill(table);
            dataGridView1.DataSource = table;
        }
    }
}


