﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BookShop_Management_System
{
    public partial class Books : Form
    {
        public Books()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\Users\alkas\source\repos\BookShop_Management_System\Database1.mdf;Integrated Security=True");
            con.Open();
            {
                try
                {
                    con.Open();
                    string title = textBox1.Text;  
                    string author = textBox2.Text;
                    string category = comboBox1.SelectedItem.ToString();
                    int quantity = int.Parse(textBox4.Text);
                    decimal price = decimal.Parse(textBox3.Text);
                    SqlCommand cnn = new SqlCommand("insert into UserTable values(@Book_Title,@Book_Author,@Book_Categories,@Book_Quantity,@Book_Price)", con);
                    SqlCommand cmd = new SqlCommand("query", con);
                    cmd.Parameters.AddWithValue("@Book_Title", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Book_Author", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Book_Categories", comboBox1.SelectedItem);
                    cmd.Parameters.AddWithValue("@Book_Quantity", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Book_Price", textBox3.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Book details saved successfully!");
                    ResetFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                con.Close();
            }
        }
        private void ResetFields()
        {
            textBox1.Clear();
            textBox2.Clear();
            comboBox1.SelectedIndex = -1;
            textBox4.Clear();
            textBox3.Clear();
        }
        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FilterSearch_SelectedIndexChar(object sender, EventArgs e)
        {
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
        }
        
    }
}
